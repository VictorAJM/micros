/*
 * practica6.c
 *
 * Created: 15/02/2024 09:05:58 a. m.
 * Author : victor
 */ 

#define F_CPU 8000000UL  // Frecuencia de trabajo del microcontrolador
#define SERVO_PIN PB3   // Pin donde est� conectado el servo
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include "lcd.h"
char mat[4][4] = {
	{'1', '2', '3', 'A'},
	{'4', '5', '6', 'B'},
	{'7', '8', '9', 'C'},
	{'E', '0', 'F', 'D'}
}; 
uint8_t p_pin;
char letra=0;
uint8_t pos=0;
char keyboard(){
	p_pin=0;
	for(uint8_t i = 0; i<4; i++){
		PORTD = 0b11111111 ^ (1<<(7-i));
		if(~PIND&1 && '0' <= mat[i][3] && mat[i][3]<='9') {p_pin = 1;return mat[i][3];}
		if(~PIND&2 && '0' <= mat[i][2] && mat[i][2]<='9') {p_pin = 2;return mat[i][2];}
		if(~PIND&4 && '0' <= mat[i][1] && mat[i][1]<='9') {p_pin = 4;return mat[i][1];}
		if(~PIND&8 && '0' <= mat[i][0] && mat[i][0]<='9') {p_pin = 8;return mat[i][0];}
	}
	return 0;
}
void wait_btn(){
	_delay_ms(50);
	while(~PIND&p_pin);
	_delay_ms(50);
}
void init() {
	DDRA = 0xFF;
	PORTA = 0x00;
	DDRC = 0xF0;
	lcd_init(LCD_DISP_ON);
	DDRD = 0xF0;
    DDRB |= (1 << SERVO_PIN);
	DDRB |= (1<<7);
    TCCR0 |= (1 << WGM00) | (1 << WGM01) | (1 << COM01) | (1<<CS02);
}
uint8_t val = 0;
void servo_rotate(uint8_t angle) {
	uint8_t duty_cycle = (angle / 180.0) * 70 + 10; 
	OCR0 = (duty_cycle / 100.0) * 255; 
	_delay_ms(100);
}
int main(void)
{
	init();
    /* Replace with your application code */
    while (1) 
    {
		if (pos < 2) {
			letra = keyboard();
			if (letra != 0) {
				if ('0' <= letra && letra <= '9') {
					// escribir en lcd
					lcd_gotoxy(pos++,0);
					lcd_putc(letra);
					val*=10;
					val+=letra-'0';
				}
				wait_btn();
			} else {
				
			}
		} else {
			uint8_t z=0;
			uint8_t cp = val;
			float x = (39.0-7.0)/val;
			float y = 7.0;
			for (int i=0;i<=val;i++) {
				servo_rotate(y);
				_delay_ms(250);
				y+=x;
				if (i) {
				lcd_gotoxy(0,0);
				lcd_putc(cp/10+'0');
				lcd_gotoxy(1,0);
				lcd_putc(cp%10+'0');
				cp--;
				}
			}
			pos=0;
			lcd_clrscr();
			PORTA = 0xff;
			PORTB |= (1<<7);
			_delay_ms(2000);
			servo_rotate(7.0);
			_delay_ms(100);
			PORTA = 0;
			PORTB &= 0b01111111;
			val=0;
		}
    }
}

