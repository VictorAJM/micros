/*
 * practica4.c
 *
 * Created: 07/02/2024 10:04:41 p. m.
 * Author : victor
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdlib.h> // Necesario para la funci�n rand()

volatile uint8_t ran;
ISR(INT0_vect) {
	ran = (rand() % 6) + 1;
	if (ran == 1) {
		PORTB = 1;
		PORTA = 0;
	} else if (ran == 2) {
		PORTB = 0;
		PORTA = (1<<5) | (1<<2);
	} else if (ran == 3) {
		PORTB = 1;
		PORTA = (1<<0) | (1<<7);
	} else if (ran == 4) {
		PORTB = 0;
		PORTA = (1<<0) | (1<<7) | (1<<5) | (1<<2);
	} else if (ran == 5) {
		PORTB = 1;
		PORTA = (1<<0) | (1<<7) | (1<<5) | (1<<2);
	} else if (ran == 6) {
		PORTB = 0;
		PORTA = (1<<0) | (1<<7) | (1<<5) | (1<<2) | (1<<1) | (1<<6);
	}
}

int main(void) {
	DDRD &= ~(1 << PD2);
	DDRA = 0xFF;
	DDRB = 0XFF;
	PORTA = 0;
	PORTB = 0;
	MCUCR |= (1 << ISC01) | (1 << ISC00);
	GICR |= (1 << INT0);
	sei();
	srand(42069);

	while (1) {
		
	}

	return 0;
}
